disp('================================== transform ==============================')
transform

disp('================================== trajectory ==============================')
trajectory

disp('================================== jacobian ==============================')
jacobian

disp('================================== kinematics ==============================')
kinematics

disp('================================== dynamics ==============================')
dynamics

disp('================================== demos ==============================')
pause off
rttrdemo
rtfkdemo
rtikdemo
rttgdemo
rtandemo
rtjademo
rtfddemo
rtidemo
