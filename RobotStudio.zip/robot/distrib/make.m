% Build a distribution of RTB

!make clean
!make
matlab.addons.toolbox.packageToolbox('RTB.prj', '~/Desktop/RTB')