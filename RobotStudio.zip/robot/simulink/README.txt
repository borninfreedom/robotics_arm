The Simulink models in this folder are generated with recent versions of Simulink.

If you are using an older version of Simulink then try the older models in the folder R2015a.  
These have been exported using save_system and should give some compatability.